package net.apmm.mdm.ops.geo.dao;


import net.apmm.mdm.ops.geo.dao.model.GeographyGrandParentAlternateCodeData;

import java.util.List;

public interface GeographyGrandParentAltCdDao {

    public List<GeographyGrandParentAlternateCodeData> retrieveGrandParentAltCodeDtlsByEntityId(Long entityId);

}

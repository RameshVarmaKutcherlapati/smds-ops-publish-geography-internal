package net.apmm.mdm.ops.geo.dao.model;

import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class GeographyBDADetailsData {
    private Long entityId;
    private String name;
    private String type;
    private String bdaType;
    private LocalDate validFrom;
    private LocalDate validTo;
    private Long createDate;
    private Long updateDate;
    private String createdBy;
    private String updatedBy;
    private String opertion;
    private String ischanged;
    List<GeographyBDAAlternateCodeData> bdaAlternateCodeData;
}

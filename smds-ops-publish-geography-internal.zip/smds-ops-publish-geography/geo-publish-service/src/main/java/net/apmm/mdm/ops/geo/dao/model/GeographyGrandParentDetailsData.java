package net.apmm.mdm.ops.geo.dao.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class GeographyGrandParentDetailsData {
    private Long entityId;
    private String name;
    private String longitude;
    private String latitude;
    private String status;
    private String type;
    private String bdatype;
    private Long createDate;
    private Long updateDate;
    private String createdBy;
    private String updatedBy;
    List<GeographyGrandParentAlternateCodeData> grandParentAlternateCode;
}

package net.apmm.mdm.ops.geo.service;

import com.maersk.geography.smds.operations.msk.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.GeographyMessageDao;
import net.apmm.mdm.ops.geo.dao.model.*;
import net.apmm.mdm.ops.geo.exception.PublishException;
import net.apmm.mdm.ops.geo.model.StatusResponse;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class PublishGeographyService {

    @Autowired

    private final GeographyMessageDao geographyMessageDao;
    @Value("${kafka.topic}")
    private String geoTopic;

    @Value("#{${geo-event-details}}")
    private Map<String, String> geoEventDetails;

    private final KafkaTemplate<String, geography> kafkaTemplate;

    private String messageId = UUID.randomUUID().toString();


    public StatusResponse publishGeographyDetails(String geoId, String eventDetails) {
        try {
            log.debug(" Processing request, Processing DB queries.... ");
            GeographyData geoMsg = geographyMessageDao.getGeographyMessage(geoId, eventDetails);
            log.debug("Geo Id is:"+geoId);
            log.debug(" Message before sending.... " + transformData(geoMsg).toString());
            final ProducerRecord<String, geography> record = new ProducerRecord<>(geoTopic, geoId, transformData(geoMsg));
            log.debug(" Record before publish " + record.toString());
            //log.debug("Kafka Template" + kafkaTemplate.toString());
            String eventType = geoEventDetails.get(eventDetails).split("\\|")[0];
            String eventDescr = geoEventDetails.get(eventDetails).split("\\|")[1];

            record.headers().add("EventType", eventType.getBytes());
            record.headers().add("EventDescription", eventDescr.getBytes());
            record.headers().add("eventDateTime", java.util.Calendar.getInstance().getTime().toString().getBytes());
            record.headers().add("messageId", messageId.getBytes());
            log.debug(" Record after header append " + record.toString());
            kafkaTemplate.send(record);
            kafkaTemplate.flush();
            log.info(" ### Geo message Published successfully to geo topic for geoId " + geoId + " ### ");
            return StatusResponse.builder().geoRowID(geoId).geoRequestId(UUID.randomUUID().toString()).build();

        } catch (Exception e) {
            log.debug("Error cause" + e.getCause());
            e.printStackTrace();
            throw new PublishException("Error while generating & publishing AVRO message :: " + e);
        }

    }

    private geography transformData(GeographyData geoMsg) {

        geography geographyInfo = new geography();

        country geographyCountry = new country();

        timezone geographyTimezone = new timezone();

        address siteAddress = new address();

        continent geographyContinent = new continent();

        parent geographyParent = new parent();

        GrandParent geographyGrandParent = new GrandParent();



        geographyInfo.setCreateDate(geoMsg.getCreateDate());
        geographyInfo.setUpdateDate(geoMsg.getUpdateDate());
        geographyInfo.setCreatedBy(geoMsg.getCreatedBy());
        geographyInfo.setUpdatedBy(geoMsg.getUpdatedBy());
        geographyInfo.setGeoId(geoMsg.getGeoId());
        geographyInfo.setGeoType(geoMsg.getGeoType());
        geographyInfo.setName(geoMsg.getName());
        geographyInfo.setStatus(geoMsg.getStatus());
        geographyInfo.setValidFrom(geoMsg.getValidFrom());
        geographyInfo.setValidTo(geoMsg.getValidTo());
        geographyInfo.setLongitude(geoMsg.getLongitude());
        geographyInfo.setLatitude(geoMsg.getLatitude());
        geographyInfo.setDescription(geoMsg.getDescription());
        geographyInfo.setWorkaroundReason(geoMsg.getWorkaroundReason());
        geographyInfo.setRestricted(geoMsg.getRestricted());
        geographyInfo.setPostalCodeMandatory(geoMsg.getPostalCodeMandatory());
        geographyInfo.setStateProvinceMandatory(geoMsg.getStateProvinceMandatory());
        geographyInfo.setDialingCode(geoMsg.getDialingCode());
        geographyInfo.setDialingCodeDescription(geoMsg.getDialingCodeDescription());
        geographyInfo.setPortFlag(geoMsg.getPortFlag());
        geographyInfo.setOlsonTimezone(geoMsg.getOlsonTimezone());
        geographyInfo.setBdaType(geoMsg.getBdaType());
        geographyInfo.setHsudName(geoMsg.getHsudName());
        geographyInfo.setIsMaerskCity(geoMsg.getIsMaerskCity());
        geographyInfo.setSiteType(geoMsg.getSiteType());


        GeographyTimeZoneData geoTimezonedata = geoMsg.getTimeZone();

        if(geoTimezonedata != null)
        {
            geographyTimezone.setTimezoneCode(geoMsg.getTimeZone().getTimezoneCode());
            geographyTimezone.setTimezoneName(geoMsg.getTimeZone().getTimezoneName());
            geographyTimezone.setUtcOffsetMinutes(geoMsg.getTimeZone().getUtcOffsetMinutes());
            geographyInfo.setTimezone(geographyTimezone);

        }

        List<dayLightSaving> geoDayLightSavingData = geoMsg.getDayLightSaving().stream()
                .map(list -> new dayLightSaving(list.getDayLightSavingCode(), list.getDayLightSavingName(),
                         list.getDaylightSavingStart(), list.getDaylightSavingEnd(), list.getDayLightSavingShiftMinutes())).collect(Collectors.toList());

        if(geoDayLightSavingData.size() != 0)
        {
            geographyInfo.setDayLightSaving(geoDayLightSavingData);
        }

        GeographySiteAddressData siteAddressdata = geoMsg.getSiteAddress();

        if(siteAddressdata != null)
        {
            siteAddress.setGpsFlag(geoMsg.getSiteAddress().getGpsFlag());
            siteAddress.setGsmFlag(geoMsg.getSiteAddress().getGsmFlag());
            siteAddress.setStreet(geoMsg.getSiteAddress().getStreet());
            siteAddress.setPostalCode(geoMsg.getSiteAddress().getPostalCode());
            siteAddress.setAddressLine1(geoMsg.getSiteAddress().getAddressLine1());
            siteAddress.setAddressLine2(geoMsg.getSiteAddress().getAddressLine2());
            siteAddress.setAddressLine3(geoMsg.getSiteAddress().getAddressLine3());
            siteAddress.setCreateDate(geoMsg.getSiteAddress().getCreateDate());
            siteAddress.setUpdateDate(geoMsg.getSiteAddress().getUpdateDate());
            siteAddress.setCreatedBy(geoMsg.getSiteAddress().getCreatedBy());
            siteAddress.setUpdatedBy(geoMsg.getSiteAddress().getUpdatedBy());
            siteAddress.setOperation(geoMsg.getSiteAddress().getOperation());
            siteAddress.setIsChanged(geoMsg.getSiteAddress().getIsChanged());
            geographyInfo.setAddress(siteAddress);

        }


        List<alternateName> geographyAlternateNamesList = geoMsg.getAlternateNames().stream()
                .map(list -> new alternateName(list.getName(),
                        list.getDescription(), list.getStatus(), list.getCreateDate(), list.getUpdateDate(), list.getCreatedBy(), list.getUpdatedBy(),
                        list.getOperation(), list.getIsChanged()
                )).collect(Collectors.toList());

        if (geographyAlternateNamesList.size() != 0)
            geographyInfo.setAlternateNames(geographyAlternateNamesList);


        List<alternateCode> geographyAlternateCodesList = geoMsg.getAlternateCodes().stream()
                .map(list -> new alternateCode(list.getCodeType(), list.getCode())).collect(Collectors.toList());

        if (geographyAlternateCodesList.size() != 0)
            geographyInfo.setAlternateCodes(geographyAlternateCodesList);


        GeographyContinentData geoContData = geoMsg.getContinent();

        if(geoContData != null)
        {
            geographyContinent.setCode(geoMsg.getContinent().getCode());
            geographyContinent.setName(geoMsg.getContinent().getName());
            geographyInfo.setContinent(geographyContinent);
        }

        GeographyCountryData geoCountrydata = geoMsg.getCountry();

        if(geoCountrydata!=null)
        {
            geographyCountry.setName(geoMsg.getCountry().getName());
            List<countryAlternateCode> geographyCountryAltCode = geoMsg.getCountry().getCountryAltCdData().stream()
                    .map(list -> new  countryAlternateCode(list.getCodeType(),list.getCode())).collect(Collectors.toList());
            if(geographyCountryAltCode.size() != 0)
            {
                geographyCountry.setAlternateCodes(geographyCountryAltCode);
            }
            geographyInfo.setCountry(geographyCountry);
        }

        GeographyParentDetailsData geoParentData = geoMsg.getParentDetails();

        if(geoParentData != null)
        {
            geographyParent.setName(geoMsg.getParentDetails().getName());
            geographyParent.setLongitude(geoMsg.getParentDetails().getLongitude());
            geographyParent.setLatitude(geoMsg.getParentDetails().getLatitude());
            geographyParent.setStatus(geoMsg.getParentDetails().getStatus());
            geographyParent.setType(geoMsg.getParentDetails().getType());
            geographyParent.setBdaType(geoMsg.getParentDetails().getBdatype());
            geographyParent.setCreateDate(geoMsg.getParentDetails().getCreateDate());
            geographyParent.setUpdateDate(geoMsg.getParentDetails().getUpdateDate());
            geographyParent.setCreatedBy(geoMsg.getParentDetails().getCreatedBy());
            geographyParent.setUpdatedBy(geoMsg.getParentDetails().getCreatedBy());
            List<parentAlternateCode> parentAltCode = geoMsg.getParentDetails().getParentAlternateCode().stream()
                    .map(list -> new  parentAlternateCode(list.getCodeType(),list.getCode())).collect(Collectors.toList());
            if(parentAltCode.size() !=0)
            {
                geographyParent.setAlternateCodes(parentAltCode);
            }
            geographyInfo.setParent(geographyParent);
        }

        GeographyGrandParentDetailsData geoGrandParentData = geoMsg.getGrandParentDetails();

        if(geoGrandParentData != null)
        {
            geographyGrandParent.setName(geoMsg.getParentDetails().getName());
            geographyGrandParent.setLongitude(geoMsg.getParentDetails().getLongitude());
            geographyGrandParent.setLatitude(geoMsg.getParentDetails().getLatitude());
            geographyGrandParent.setStatus(geoMsg.getParentDetails().getStatus());
            geographyGrandParent.setType(geoMsg.getParentDetails().getType());
            geographyGrandParent.setBdaType(geoMsg.getParentDetails().getBdatype());
            geographyGrandParent.setCreateDate(geoMsg.getParentDetails().getCreateDate());
            geographyGrandParent.setUpdateDate(geoMsg.getParentDetails().getUpdateDate());
            geographyGrandParent.setCreatedBy(geoMsg.getParentDetails().getCreatedBy());
            geographyGrandParent.setUpdatedBy(geoMsg.getParentDetails().getCreatedBy());
            List<grandParentAlternateCode> grandParentAltCode = geoMsg.getGrandParentDetails().getGrandParentAlternateCode().stream()
                    .map(list -> new  grandParentAlternateCode(list.getCodeType(),list.getCode())).collect(Collectors.toList());
            if(grandParentAltCode.size() !=0)
            {
                geographyGrandParent.setAlternateCodes(grandParentAltCode);
            }
            geographyInfo.setGrandParent(geographyGrandParent);
        }



        List<subCityParent> geographySubCityPrntDetailsList = geoMsg.getSubCityParentDetails().stream()
                .map(list -> new subCityParent(list.getName(), list.getType(), list.getBdatype(),
                        list.getSubCityParentAlternateCode().stream()
                                .map(l -> new subCityParentAlternateCode(l.getCodeType(), l.getCode())).collect(Collectors.toList())))
                .collect(Collectors.toList());

        for (subCityParent prntDetails : geographySubCityPrntDetailsList) {
            for (subCityParentAlternateCode sunCityparentAltCd : prntDetails.getAlternateCodes()) {
                if (sunCityparentAltCd.getCodeType() == null &&
                        sunCityparentAltCd.getCode() == null)
                    prntDetails.setAlternateCodes(null);

            }
        }
        if (geographySubCityPrntDetailsList.size() != 0)
            geographyInfo.setSubCityParents(geographySubCityPrntDetailsList);


        List<bda> geographyBDADetailsList = geoMsg.getBdaDetails().stream()
                .map(list -> new bda( list.getName(), list.getType(), list.getBdaType(), list.getValidFrom(), list.getValidTo(),
                        list.getCreateDate(), list.getUpdateDate(), list.getCreatedBy(), list.getUpdatedBy(), list.getOpertion(), list.getIschanged(),
                        list.getBdaAlternateCodeData().stream()
                                .map(l -> new bdaAlternateCode(l.getCodeType(), l.getCode())).collect(Collectors.toList())))
                .collect(Collectors.toList());


        for (bda bdaDetails : geographyBDADetailsList) {
            for (bdaAlternateCode bdaAltCdDetails : bdaDetails.getAlternateCodes()) {
                if (bdaAltCdDetails.getCodeType() == null &&
                        bdaAltCdDetails.getCode() == null)
                    bdaDetails.setAlternateCodes(null);

            }

        }
        if (geographyBDADetailsList.size() != 0)
            geographyInfo.setBdas(geographyBDADetailsList);


        List<bdaLocation> geoBDALocDetailsList = geoMsg.getBdaLocationsDetails().stream()
                .map(list -> new bdaLocation( list.getName(), list.getType(), list.getStatus(),
                        list.getBDALocationAlternateCodeData().stream()
                                .map(l -> new bdaLocationAlternateCode(l.getCodeType(), l.getCode())).collect(Collectors.toList())))
                .collect(Collectors.toList());


        for (bdaLocation bdaLocDetails : geoBDALocDetailsList) {
            for (bdaLocationAlternateCode bdaLocAltCdDetails : bdaLocDetails.getAlternateCodes()) {
                if (bdaLocAltCdDetails.getCodeType() == null &&
                        bdaLocAltCdDetails.getCode() == null)
                    bdaLocDetails.setAlternateCodes(null);

            }

        }
        if (geoBDALocDetailsList.size() != 0)
            geographyInfo.setBdaLocations(geoBDALocDetailsList);


        return geographyInfo;
    }

}

package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographyCountryData;
import net.apmm.mdm.ops.geo.dao.model.GeographyGrandParentDetailsData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographyGrandParentDaoImpl implements GeographyGrandParentDao
{
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveGrandParentByUuid")
    @Autowired
    String retrieveGrandParentByUuid;

    @Autowired
    public GeographyGrandParentDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }



    @Override
    public GeographyGrandParentDetailsData retrieveGrandParentDetailsByUuid(String uuid) {
        log.debug("Fetching grand Parent Details for uuid :: " + uuid);
        try {

            List<GeographyGrandParentDetailsData> GeographyGrandParentDetailsData = (List<GeographyGrandParentDetailsData>)smdsJdbcTemplate.query(retrieveGrandParentByUuid,
                    new Object[]{uuid},
                    new GeographyGrandParentMapper()
            );
            return GeographyGrandParentDetailsData.get(0);
        } catch (Exception e) {
            throw new DataRetrievalException("Error getting CountryDetails Details:: " + e);
        }
    }
}

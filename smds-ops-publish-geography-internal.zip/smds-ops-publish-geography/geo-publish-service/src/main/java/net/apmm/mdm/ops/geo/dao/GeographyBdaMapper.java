package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyBDADetailsData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyBdaMapper implements RowMapper<GeographyBDADetailsData> {


    @Override
    public GeographyBDADetailsData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyBDADetailsData.builder()
                .entityId(resultSet.getLong("entityId"))
                .name(resultSet.getString("name"))
                .type(resultSet.getString("type"))
                .bdaType(resultSet.getString("bdaType"))
                .validFrom(resultSet.getDate("validFrom").toLocalDate())
                .validTo(resultSet.getDate("validTo").toLocalDate())
                .createDate(resultSet.getLong("createDate"))
                .updateDate(resultSet.getLong("updateDate"))
                .createdBy(resultSet.getString("createdBy"))
                .updatedBy(resultSet.getString("updatedBy"))
                .opertion(resultSet.getString("updatedBy"))
                .ischanged(resultSet.getString("updatedBy"))
                .build();
    }
}

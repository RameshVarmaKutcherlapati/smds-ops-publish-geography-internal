package net.apmm.mdm.ops.geo.dao;




import net.apmm.mdm.ops.geo.dao.model.GeographyCountryData;


public interface GeographyCountryDao {

    public GeographyCountryData retrieveCountryDetailsByUuid
            (String uuid);

}

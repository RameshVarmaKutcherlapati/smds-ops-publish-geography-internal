package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyDayLightSavingData;

import java.util.List;

public interface GeographyDayLightSavingDao {
    public List<GeographyDayLightSavingData> retrieveDayLightSavingDetailsBydstId(Long dstId);
}

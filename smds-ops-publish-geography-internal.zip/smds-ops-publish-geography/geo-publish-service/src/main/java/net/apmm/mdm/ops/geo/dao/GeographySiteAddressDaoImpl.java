package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographySiteAddressData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographySiteAddressDaoImpl implements GeographySiteAddressDao{
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveSiteAddressByRowId")
    @Autowired
    String retrieveSiteAddressByRowId;

    @Autowired
    public GeographySiteAddressDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }
    @Override
    public GeographySiteAddressData retrieveSiteAddressDetailsByrowId(Long entityId) {
        log.debug("Fetching entityId and header Info  :: " + entityId);
        try{
            List<GeographySiteAddressData> GeographySiteAddressData = (List<GeographySiteAddressData>) smdsJdbcTemplate.query(retrieveSiteAddressByRowId,
                    new Object[]{entityId},
                    new GeographySiteAddressMapper()
            );
            return GeographySiteAddressData.get(0);
        }
        catch (Exception e) {
            throw new DataRetrievalException("Error getting GeographySiteAddress details  :: " + e);
        }


    }
}

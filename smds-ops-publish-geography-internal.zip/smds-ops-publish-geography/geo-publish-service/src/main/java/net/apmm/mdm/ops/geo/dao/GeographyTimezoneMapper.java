package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyTimeZoneData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyTimezoneMapper implements RowMapper<GeographyTimeZoneData> {


    @Override
    public GeographyTimeZoneData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyTimeZoneData.builder()
                .timezoneCode(resultSet.getString("timezoneCode"))
                .timezoneName(resultSet.getString("timezoneName"))
                .utcOffsetMinutes(resultSet.getString("utcOffsetMinutes"))
                .build();
    }
}

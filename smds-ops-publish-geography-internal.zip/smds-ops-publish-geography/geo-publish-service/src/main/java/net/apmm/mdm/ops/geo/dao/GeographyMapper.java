package net.apmm.mdm.ops.geo.dao;

import lombok.SneakyThrows;
import net.apmm.mdm.ops.geo.dao.model.GeographyData;
import org.springframework.jdbc.core.RowMapper;
import net.apmm.mdm.ops.geo.util.DatetoLong;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDate;

public class GeographyMapper implements RowMapper<GeographyData> {

    DatetoLong dl = new DatetoLong();





    @SneakyThrows
    @Override
    public GeographyData mapRow(ResultSet resultSet, int i) throws SQLException {

            return GeographyData.builder()
                    .entityId(resultSet.getLong("entityId"))
                    .createDate(resultSet.getLong("createDate"))
                    .updateDate(resultSet.getLong("updateDate"))
                    .createdBy(resultSet.getString("createdBy"))
                    .updatedBy(resultSet.getString("updatedBy"))
                    .geoId(resultSet.getString("geoId"))
                    .geoType(resultSet.getString("geoType"))
                    .name(resultSet.getString("name"))
                    .status(resultSet.getString("status"))
                    .validFrom(resultSet.getDate("validFrom").toLocalDate())
                    .validTo(resultSet.getDate("validTo").toLocalDate())
                    .longitude(resultSet.getString("longitude"))
                    .latitude(resultSet.getString("latitude"))
                    .description(resultSet.getString("description"))
                    .workaroundReason(resultSet.getString("workaroundReason"))
                    .restricted(resultSet.getString("restricted"))
                    .postalCodeMandatory(resultSet.getString("postalCodeMandatory"))
                    .stateProvinceMandatory(resultSet.getString("stateProvinceMandatory"))
                    .dialingCode(resultSet.getString("dialingCode"))
                    .dialingCodeDescription(resultSet.getString("dialingCodeDescription"))
                    .portFlag(resultSet.getString("portFlag"))
                    .olsonTimezone(resultSet.getString("olsonTimezone"))
                    .bdaType(resultSet.getString("bdaType"))
                    .hsudName(resultSet.getString("hsudName"))
                    .isMaerskCity(resultSet.getString("isMaerskCity"))
                    .siteType(resultSet.getString("siteType"))
                    .dstId(resultSet.getLong("dstId"))
                    .timezoneId(resultSet.getLong("timezoneId"))
                    .uuid(resultSet.getString("uuid"))
                    .build();

    }
}
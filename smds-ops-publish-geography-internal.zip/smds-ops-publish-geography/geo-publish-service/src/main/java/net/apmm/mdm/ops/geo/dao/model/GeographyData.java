package net.apmm.mdm.ops.geo.dao.model;

import lombok.Builder;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
@Data
@Builder
public class GeographyData {
    private Long entityId;
    private Long createDate;
    private Long updateDate;
    private String createdBy;
    private String updatedBy;
    private String geoId;
    private String geoType;
    private String name;
    private String status;
    private LocalDate validFrom;
    private LocalDate validTo;
    private String longitude;
    private String latitude;
    private String description;
    private String workaroundReason;
    private String restricted;
    private String postalCodeMandatory;
    private String stateProvinceMandatory;
    private String dialingCode;
    private String dialingCodeDescription;
    private String portFlag;
    private String olsonTimezone;
    private String bdaType;
    private String hsudName;
    private String isMaerskCity;
    private String siteType;
    private Long dstId;
    private Long timezoneId;
    private String uuid;
    private GeographyTimeZoneData timeZone;
    List<GeographyDayLightSavingData> dayLightSaving;
    private GeographySiteAddressData siteAddress;
    List<GeographyAlternateNameData> alternateNames;
    List<GeographyAlternateCodesData> alternateCodes;
    private GeographyContinentData continent;
    private GeographyCountryData country;
    private GeographyParentDetailsData parentDetails;
    private GeographyGrandParentDetailsData grandParentDetails;
    List<GeographySubCityParentDetailsData> subCityParentDetails;
    List<GeographyBDADetailsData> bdaDetails;
    List<GeographyBDALocationsDetailsData> bdaLocationsDetails;






}

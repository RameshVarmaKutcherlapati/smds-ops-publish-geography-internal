package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographySubCityParentDetailsData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographySubCityParentDaoImpl implements GeographySubCityParentDao
{
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveSubCityParentByUuid")
    @Autowired
    String retrieveSubCityParentByUuid;

    @Autowired
    public GeographySubCityParentDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }



    @Override
    public List<GeographySubCityParentDetailsData> retrieveSubCityParentDetailsByUuid(String uuid) {
        log.debug("Fetching subcity details for uuid :: " + uuid);
        try {
            return smdsJdbcTemplate.query(retrieveSubCityParentByUuid,
                    new Object[]{uuid},
                    new GeographySubCityParentMapper()
            );
        } catch (Exception e) {
            throw new DataRetrievalException("Error getting ParentDetails Details:: " + e);
        }
    }


}

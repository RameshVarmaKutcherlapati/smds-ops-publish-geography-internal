package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographySiteAddressData;

public interface GeographySiteAddressDao {

    public GeographySiteAddressData retrieveSiteAddressDetailsByrowId(Long entityId);
}

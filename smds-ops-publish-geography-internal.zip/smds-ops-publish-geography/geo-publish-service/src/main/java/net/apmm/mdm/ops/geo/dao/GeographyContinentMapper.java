package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyContinentData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyContinentMapper implements RowMapper<GeographyContinentData>{
    @Override
    public GeographyContinentData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyContinentData.builder()
                .Code(resultSet.getString("Code"))
                .name(resultSet.getString("name"))
                .build();
    }
}

package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyGrandParentDetailsData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyGrandParentMapper implements RowMapper<GeographyGrandParentDetailsData> {
    @Override
    public GeographyGrandParentDetailsData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyGrandParentDetailsData.builder()
                .name(resultSet.getString("name"))
                .longitude(resultSet.getString("longitude"))
                .latitude(resultSet.getString("latitude"))
                .status(resultSet.getString("status"))
                .type(resultSet.getString("type"))
                .bdatype(resultSet.getString("bdatype"))
                .createDate(resultSet.getLong("createDate"))
                .updateDate(resultSet.getLong("updateDate"))
                .createdBy(resultSet.getString("createdBy"))
                .updatedBy(resultSet.getString("updatedBy"))
                .build();
    }
}

package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographyTimeZoneData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographyTimezoneDaoImpl implements GeographyTimezoneDao{
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveTimezoneByRowId")
    @Autowired
    String retrieveTimezoneByRowId;

    @Autowired
    public GeographyTimezoneDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }
    @Override
    public GeographyTimeZoneData retrieveTimezoneDetailsByTimezoneId(Long timezoneId) {
        log.debug("Fetching timezoneId and header Info  :: " + timezoneId);
        try{
            List<GeographyTimeZoneData> GeographyTimeZoneData = (List<GeographyTimeZoneData>) smdsJdbcTemplate.query(retrieveTimezoneByRowId,
                    new Object[]{timezoneId},
                    new GeographyTimezoneMapper()
            );
            return GeographyTimeZoneData.get(0);
        }
        catch (Exception e) {
            throw new DataRetrievalException("Error getting GeographyTimezone details  :: " + e);
        }


    }
}

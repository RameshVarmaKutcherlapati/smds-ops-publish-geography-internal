package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyDayLightSavingData;
import net.apmm.mdm.ops.geo.dao.model.GeographyParentDetailsData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyDayLightSavingMapper implements RowMapper<GeographyDayLightSavingData>{
    @Override
    public GeographyDayLightSavingData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyDayLightSavingData.builder()
                .dayLightSavingCode(resultSet.getString("dayLightSavingCode"))
                .dayLightSavingName(resultSet.getString("dayLightSavingName"))
                .daylightSavingStart(resultSet.getDate("daylightSavingStart").toLocalDate())
                .daylightSavingEnd(resultSet.getDate("daylightSavingEnd").toLocalDate())
                .dayLightSavingShiftMinutes(resultSet.getString("daylightSavingEnd"))
                .build();
    }
}

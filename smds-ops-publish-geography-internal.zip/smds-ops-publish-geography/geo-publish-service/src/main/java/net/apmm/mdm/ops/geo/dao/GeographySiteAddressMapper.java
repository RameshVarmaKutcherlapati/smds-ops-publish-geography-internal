package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographySiteAddressData;
import net.apmm.mdm.ops.geo.dao.model.GeographyTimeZoneData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographySiteAddressMapper implements  RowMapper<GeographySiteAddressData>{
    @Override
    public GeographySiteAddressData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographySiteAddressData.builder()
                .gpsFlag(resultSet.getString("gpsFlag"))
                .gsmFlag(resultSet.getString("gsmFlag"))
                .street(resultSet.getString("street"))
                .postalCode(resultSet.getString("postalCode"))
                .addressLine1(resultSet.getString("addressLine1"))
                .addressLine2(resultSet.getString("addressLine2"))
                .addressLine3(resultSet.getString("addressLine3"))
                .createDate(resultSet.getLong("createDate"))
                .updateDate(resultSet.getLong("updateDate"))
                .createdBy(resultSet.getString("createdBy"))
                .updatedBy(resultSet.getString("updatedBy"))
                .operation(resultSet.getString("operation"))
                .isChanged(resultSet.getString("isChanged"))
                .build();
    }
}

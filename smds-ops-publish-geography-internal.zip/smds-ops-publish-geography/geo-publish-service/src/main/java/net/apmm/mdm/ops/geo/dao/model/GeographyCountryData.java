package net.apmm.mdm.ops.geo.dao.model;

import java.util.List;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class GeographyCountryData {
    private Long entityId;
    private Long createDate;
    private Long updateDate;
    private String createdBy;
    private String updatedBy;
    private String name;
    private String status;
    List<GeographyCountryAltCdData> countryAltCdData;
}

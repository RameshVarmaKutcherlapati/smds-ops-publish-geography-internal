package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyTimeZoneData;

public interface GeographyTimezoneDao {

    public GeographyTimeZoneData retrieveTimezoneDetailsByTimezoneId(Long timezoneId);

}

package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographyBDAAlternateCodeData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographyBdaAltCdDaoImpl implements GeographyBdaAltCdDao {
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveBdaAltCodeByEntityId")
    @Autowired
    String retrieveBdaAltCodeByEntityId;

    @Autowired
    public GeographyBdaAltCdDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }


    @Override
    public List<GeographyBDAAlternateCodeData> retrieveBdaAltDetailsCodeByEntityId(Long entityId) {
        log.debug("Fetching BDA ALT CODE Details for entityId :: " + entityId);
        try {
            return smdsJdbcTemplate.query(retrieveBdaAltCodeByEntityId,
                    new Object[]{entityId},
                    new GeographyBdaAltCdMapper()
            );
        } catch (Exception e) {
            throw new DataRetrievalException("Error getting BDAALTCODE Details :: " + e);
        }
    }

}

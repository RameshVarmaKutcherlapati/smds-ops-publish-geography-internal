package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographyGrandParentAlternateCodeData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographyGrandParentAltCdDaoImpl implements GeographyGrandParentAltCdDao
{
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveGrandParentAltCodeByEntityId")
    @Autowired
    String retrieveGrandParentAltCodeByEntityId;

    @Autowired
    public GeographyGrandParentAltCdDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }



    @Override
    public List<GeographyGrandParentAlternateCodeData> retrieveGrandParentAltCodeDtlsByEntityId(Long entityId) {
        log.debug("Fetching ParentDetails for entityId :: " + entityId);
        try {
            return smdsJdbcTemplate.query(retrieveGrandParentAltCodeByEntityId,
                    new Object[]{entityId},
                    new GeographyGrandParentAltCdMapper()
            );
        } catch (Exception e) {
            throw new DataRetrievalException("Error getting Parent Alternate code Details:: " + e);
        }
    }
}

package net.apmm.mdm.ops.geo.dao;


import net.apmm.mdm.ops.geo.dao.model.GeographyGrandParentDetailsData;

public interface
GeographyGrandParentDao {

    public GeographyGrandParentDetailsData retrieveGrandParentDetailsByUuid(String uuid);

}

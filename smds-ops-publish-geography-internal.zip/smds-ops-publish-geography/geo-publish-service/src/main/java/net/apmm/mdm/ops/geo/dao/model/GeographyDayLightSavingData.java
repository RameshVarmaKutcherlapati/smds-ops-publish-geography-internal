package net.apmm.mdm.ops.geo.dao.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class GeographyDayLightSavingData {

    private String dayLightSavingCode;
    private String dayLightSavingName;
    private LocalDate daylightSavingStart;
    private LocalDate daylightSavingEnd;
    private String dayLightSavingShiftMinutes;
}

package net.apmm.mdm.ops.geo.dao.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GeographyTimeZoneData {
    private String timezoneCode;
    private String timezoneName;
    private String utcOffsetMinutes;
}

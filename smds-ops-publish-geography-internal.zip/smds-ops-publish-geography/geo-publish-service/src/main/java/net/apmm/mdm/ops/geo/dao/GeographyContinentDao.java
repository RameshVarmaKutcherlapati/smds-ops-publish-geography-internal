package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyContinentData;

public interface GeographyContinentDao {

    public GeographyContinentData retrieveContinentDetailsByUuid(String uuid);

}

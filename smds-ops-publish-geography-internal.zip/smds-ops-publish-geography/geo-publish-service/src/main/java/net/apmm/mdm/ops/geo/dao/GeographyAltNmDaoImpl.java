package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographyAlternateNameData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographyAltNmDaoImpl implements GeographyAltNmDao {

    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveAltNameByRowId")
    @Autowired
    String retrieveAltNameByRowId;

    @Autowired
    public GeographyAltNmDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<GeographyAlternateNameData> retrieveAltNameDetailsByRowId(Long entityId) {
        log.debug("Fetching  Details for GeoAltNm :: " + entityId);
        try {

            return smdsJdbcTemplate.query(retrieveAltNameByRowId,
                    new Object[]{entityId},
                    new GeographyAltNmMapper()

            );
        } catch (Exception e) {
            throw new DataRetrievalException("Error getting geoAltnm details  :: " + e);
        }


    }


}

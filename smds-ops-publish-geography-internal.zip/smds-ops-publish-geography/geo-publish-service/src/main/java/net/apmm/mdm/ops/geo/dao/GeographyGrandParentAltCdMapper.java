package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyGrandParentAlternateCodeData;
import net.apmm.mdm.ops.geo.dao.model.GeographyGrandParentDetailsData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyGrandParentAltCdMapper implements RowMapper<GeographyGrandParentAlternateCodeData> {
    @Override
    public GeographyGrandParentAlternateCodeData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyGrandParentAlternateCodeData.builder()
                .codeType(resultSet.getString("codeType"))
                .code(resultSet.getString("code"))
                .build();
    }
}

package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographyContinentData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographyContinentDaoImpl implements GeographyContinentDao
{
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveContinentbyUuid")
    @Autowired
    String retrieveContinentbyUuid;

    @Autowired
    public GeographyContinentDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }



    @Override
    public GeographyContinentData retrieveContinentDetailsByUuid(String uuid) {
        log.debug("Fetching continent Details for Uuid :: " + uuid);
        try {

            List<GeographyContinentData> GeographyContinentData = (List<GeographyContinentData>)smdsJdbcTemplate.query(retrieveContinentbyUuid,
                    new Object[]{uuid},
                    new GeographyContinentMapper()
            );
            return GeographyContinentData.get(0);
        } catch (Exception e) {
            throw new DataRetrievalException("Error getting Continent Details:: " + e);
        }
    }
}

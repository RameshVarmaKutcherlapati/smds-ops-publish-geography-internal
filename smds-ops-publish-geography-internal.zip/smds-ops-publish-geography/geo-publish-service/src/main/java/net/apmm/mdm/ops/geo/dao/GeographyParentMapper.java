package net.apmm.mdm.ops.geo.dao;



import net.apmm.mdm.ops.geo.dao.model.GeographyParentDetailsData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyParentMapper implements RowMapper<GeographyParentDetailsData> {


    @Override
    public GeographyParentDetailsData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyParentDetailsData.builder()
                .name(resultSet.getString("name"))
                .longitude(resultSet.getString("longitude"))
                .latitude(resultSet.getString("latitude"))
                .status(resultSet.getString("status"))
                .type(resultSet.getString("type"))
                .bdatype(resultSet.getString("bdatype"))
                .createDate(resultSet.getLong("createDate"))
                .updateDate(resultSet.getLong("updateDate"))
                .createdBy(resultSet.getString("createdBy"))
                .updatedBy(resultSet.getString("updatedBy"))
                .build();
    }
}

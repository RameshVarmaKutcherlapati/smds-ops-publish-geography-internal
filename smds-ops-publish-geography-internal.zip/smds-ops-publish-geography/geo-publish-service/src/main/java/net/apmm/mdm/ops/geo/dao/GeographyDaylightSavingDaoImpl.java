package net.apmm.mdm.ops.geo.dao;

import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.GeographyDayLightSavingData;
import net.apmm.mdm.ops.geo.dao.model.GeographyTimeZoneData;
import net.apmm.mdm.ops.geo.exception.DataRetrievalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GeographyDaylightSavingDaoImpl implements GeographyDayLightSavingDao{
    private final JdbcTemplate smdsJdbcTemplate;

    @Qualifier("retrieveDayLightByRowId")
    @Autowired
    String retrieveDayLightByRowId;

    @Autowired
    public GeographyDaylightSavingDaoImpl(@Qualifier("smdsJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.smdsJdbcTemplate = jdbcTemplate;
    }
    @Override
    public List<GeographyDayLightSavingData> retrieveDayLightSavingDetailsBydstId(Long dstId) {
        log.debug("Fetching dstId and header Info  :: " + dstId);
        try{
            return smdsJdbcTemplate.query(retrieveDayLightByRowId,
                    new Object[]{dstId},
                    new GeographyDayLightSavingMapper()
            );
        }
        catch (Exception e) {
            throw new DataRetrievalException("Error getting GeographyTimezone details  :: " + e);
        }


    }
}

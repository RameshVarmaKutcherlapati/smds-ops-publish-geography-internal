package net.apmm.mdm.ops.geo.dao;


import lombok.extern.slf4j.Slf4j;
import net.apmm.mdm.ops.geo.dao.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Repository
@Slf4j
public class GeographyMessageDao {
    @Autowired
    private GeographyDao geographyDao;
    @Autowired
    private GeographyTimezoneDao GeographyTimezoneDao;
    @Autowired
    private GeographyDayLightSavingDao GeographyDayLightSavingDao;
    @Autowired
    private GeographySiteAddressDao GeographySiteAddressDao;
    @Autowired
    private GeographyAltNmDao GeographyAltNmDao;
    @Autowired
    private GeographyAltCdDao GeographyAltCdDao;
    @Autowired
    private GeographyContinentDao GeographyContinentDao;
    @Autowired
    private GeographyCountryDao GeographyCountryDao;
    @Autowired
    private GeographyCountryAltCdDao GeographyCountryAltCdDao;
    @Autowired
    private GeographyParentDao GeographyParentDao;
    @Autowired
    private GeographyParentAltCdDao GeographyParentAltCdDao;
    @Autowired
    private GeographyGrandParentDao GeographyGrandParentDao;
    @Autowired
    private GeographyGrandParentAltCdDao GeographyGrandParentAltCdDao;
    @Autowired
    private GeographySubCityParentDao GeographySubCityParentDao;
    @Autowired
    private GeographySubCityParentAltCdDao GeographySubCityParentAltCdDao;
    @Autowired
    private GeographyBdaDao GeographyBdaDao;
    @Autowired
    private GeographyBdaAltCdDao GeographyBdaAltCdDao;
    @Autowired
    private GeographyBdaLocationDao GeographyBdaLocationDao;
    @Autowired
    private GeographyBdaLocationAltCdDao GeographyBdaLocationAltCdDao;

    @Value("#{${geo-event-details}}")
    private Map<String, String> geoEventDetails;

    public GeographyData getGeographyMessage(String geoId, String eventDetails) throws Exception {

        List<GeographyGrandParentAlternateCodeData> grandParentAltCdData = new ArrayList<>();
        List<GeographyParentAlternateCodeData> parentAltCdData = new ArrayList<>();
        List<GeographySubCityParentAlternateCodeData> subCityParentAltCdData = new ArrayList<>();
        List<GeographyBDAAlternateCodeData> bdaAlternateCodeData = new ArrayList<>();
        List<GeographyBDALocationAlternateCodeData> bdaLocationAltCdData = new ArrayList<>();

        GeographyData geography = geographyDao.retrieveGeographyDetailsByGeoId(geoId);

        GeographyTimeZoneData timezoneDtls = null;

        if (geography.getTimeZone() != null)
        {
            timezoneDtls = GeographyTimezoneDao.retrieveTimezoneDetailsByTimezoneId(geography.getTimezoneId());
        }

        List<GeographyDayLightSavingData> daylightDtls = new ArrayList<>();
        if(geography.getDstId()!=null)
        {
            daylightDtls = GeographyDayLightSavingDao.retrieveDayLightSavingDetailsBydstId(geography.getDstId());
        }

        GeographySiteAddressData siteAdressData = null;

        if(geography.getGeoType().equals("Site"))
        {
            siteAdressData = GeographySiteAddressDao.retrieveSiteAddressDetailsByrowId(geography
                    .getEntityId());
        }


        List<GeographyAlternateNameData> geoAlternateNamesList = GeographyAltNmDao.retrieveAltNameDetailsByRowId(geography.getEntityId());
        List<GeographyAlternateCodesData> geoAlternateCodeList = GeographyAltCdDao.retrieveAltCodeDetailsByRowId(geography.getEntityId());

        GeographyContinentData continentData = null;

        if(geography.getGeoType().equals("Country")
                || geography.getGeoType().equals("State/Prov")
                || geography.getGeoType().equals("City")
                || geography.getGeoType().equals("City Sub Area")
                || geography.getGeoType().equals("Site")
                || geography.getGeoType().equals("Postal Code")
        )
        {
            log.debug("Fetching Continent Details for Ramesh :: ");
            continentData = GeographyContinentDao.retrieveContinentDetailsByUuid(geography.getUuid());
        }
        GeographyCountryData geographyCountryData = null;

        if(geography.getGeoType().equals("State/Prov")
                || geography.getGeoType().equals("City")
                || geography.getGeoType().equals("City Sub Area")
                || geography.getGeoType().equals("Site")
                || geography.getGeoType().equals("Postal Code"))
        {
            log.debug("Fetching Country Details for Ramesh :: ");
            geographyCountryData = GeographyCountryDao.retrieveCountryDetailsByUuid(geography.getUuid());
            List<GeographyCountryAltCdData> countryAltCodeData = GeographyCountryAltCdDao.retrieveCountryAltCodeDetailsByCountryId(geographyCountryData.getEntityId());
            geographyCountryData.setCountryAltCdData(countryAltCodeData);
        }

        GeographyParentDetailsData parentDetailsList = null;

        if(!geography.getGeoType().equalsIgnoreCase("Continent")) {
            parentDetailsList = GeographyParentDao.retrieveParentDetailsByUuid(geography.getUuid());
            List<GeographyParentAlternateCodeData> parentAltCodeData = GeographyParentAltCdDao.retrieveParentAltCodeDtlsByEntityId(parentDetailsList.getEntityId());
            parentDetailsList.setParentAlternateCode(parentAltCodeData);

        }

        GeographyGrandParentDetailsData grandParentDetailsList = null;


        if(!geography.getGeoType().equals("Continent")
        ||!geography.getGeoType().equals("Country")) {

            grandParentDetailsList = GeographyGrandParentDao.retrieveGrandParentDetailsByUuid(geography.getUuid());
            List<GeographyGrandParentAlternateCodeData> grandParentAltCodeData = GeographyGrandParentAltCdDao.retrieveGrandParentAltCodeDtlsByEntityId(grandParentDetailsList.getEntityId());
            grandParentDetailsList.setGrandParentAlternateCode(grandParentAltCodeData);

        }

        List<GeographySubCityParentDetailsData> subcityparentDetailsList = GeographySubCityParentDao.retrieveSubCityParentDetailsByUuid(geography.getUuid());
        for (GeographySubCityParentDetailsData subcityparentRowidList : subcityparentDetailsList) {
            subCityParentAltCdData = GeographySubCityParentAltCdDao.retrieveSubCityParentAltCodeDtlsByEntityId(subcityparentRowidList.getEntityId());
            subcityparentRowidList.setSubCityParentAlternateCode(subCityParentAltCdData);
        }
        List<GeographyBDADetailsData> bdaDetailsList = GeographyBdaDao.retrieveBdaDetailsByUuid(geography.getUuid());
        for (GeographyBDADetailsData bdaRowidList : bdaDetailsList) {
            bdaAlternateCodeData = GeographyBdaAltCdDao.retrieveBdaAltDetailsCodeByEntityId(bdaRowidList.getEntityId());
            bdaRowidList.setBdaAlternateCodeData(bdaAlternateCodeData);
        }

        List<GeographyBDALocationsDetailsData> bdaLocDetailsList = GeographyBdaLocationDao.retrieveBdaLocationDtlsByEntityId(geography.getEntityId());
        for (GeographyBDALocationsDetailsData bdaLocRowidList : bdaLocDetailsList) {
            bdaLocationAltCdData = GeographyBdaLocationAltCdDao.retrieveBdaLocationdtlsAltCodeByEntityId(bdaLocRowidList.getEntityId());
            bdaLocRowidList.setBDALocationAlternateCodeData(bdaLocationAltCdData);
        }









        return GeographyData.builder()
                .entityId(geography.getEntityId())
                .createDate(geography.getCreateDate())
                .updateDate(geography.getUpdateDate())
                .createdBy(geography.getCreatedBy())
                .updatedBy(geography.getUpdatedBy())
                .geoId(geography.getGeoId())
                .geoType(geography.getGeoType())
                .name(geography.getName())
                .status(geography.getStatus())
                .validFrom(geography.getValidFrom())
                .validTo(geography.getValidTo())
                .longitude(geography.getLongitude())
                .latitude(geography.getLatitude())
                .description(geography.getDescription())
                .workaroundReason(geography.getWorkaroundReason())
                .restricted(geography.getRestricted())
                .postalCodeMandatory(geography.getPostalCodeMandatory())
                .stateProvinceMandatory(geography.getStateProvinceMandatory())
                .dialingCode(geography.getDialingCode())
                .dialingCodeDescription(geography.getDialingCodeDescription())
                .portFlag(geography.getPortFlag())
                .olsonTimezone(geography.getOlsonTimezone())
                .bdaType(geography.getBdaType())
                .hsudName(geography.getHsudName())
                .isMaerskCity(geography.getIsMaerskCity())
                .siteType(geography.getSiteType())
                .dstId(geography.getDstId())
                .timezoneId(geography.getTimezoneId())
                .uuid(geography.getUuid())
                .timeZone(timezoneDtls)
                .dayLightSaving(daylightDtls)
                .siteAddress(siteAdressData)
                .alternateNames(geoAlternateNamesList)
                .alternateCodes(geoAlternateCodeList)
                .continent(continentData)
                .country(geographyCountryData)
                .parentDetails(parentDetailsList)
                .grandParentDetails(grandParentDetailsList)
                .subCityParentDetails(subcityparentDetailsList)
                .bdaDetails(bdaDetailsList)
                .bdaLocationsDetails(bdaLocDetailsList).build();


    }


}

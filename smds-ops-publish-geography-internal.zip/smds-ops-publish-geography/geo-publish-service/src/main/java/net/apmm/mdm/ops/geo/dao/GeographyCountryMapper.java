package net.apmm.mdm.ops.geo.dao;

import net.apmm.mdm.ops.geo.dao.model.GeographyCountryData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GeographyCountryMapper implements RowMapper<GeographyCountryData> {


    @Override
    public GeographyCountryData mapRow(ResultSet resultSet, int i) throws SQLException {
        return GeographyCountryData.builder()
                .createDate(resultSet.getLong("createDate"))
                .updateDate(resultSet.getLong("updateDate"))
                .createdBy(resultSet.getString("createdBy"))
                .updatedBy(resultSet.getString("updatedBy"))
                .name(resultSet.getString("name"))
                .status(resultSet.getString("status"))
                .build();
    }
}

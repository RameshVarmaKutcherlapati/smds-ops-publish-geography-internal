package net.apmm.mdm.ops.geo.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.*;
import java.util.stream.Collectors;

@Configuration
@Slf4j
public class QueriesConfiguration {

    @Bean("retrieveGeographyByGeoId")
    public String retrieveGeographyByGeoId()
    {
        return readFileSql("queries/retrieve_geographyInfo_by_geoId.sql");
    }

    @Bean("retrieveTimezoneByRowId")
    public String retrieveTimezoneByRowId()
    {
        return readFileSql("queries/retrieve_timezoneInfo_by_rowid.sql");
    }

    @Bean("retrieveDayLightByRowId")
    public String retrieveDayLightByRowId()
    {
        return readFileSql("queries/retrieve_daylightsavingInfo_by_rowid.sql");
    }

    @Bean("retrieveSiteAddressByRowId")
    public String retrieveSiteAddressByRowId()
    {
        return readFileSql("queries/retrieve_siteaddressInfo_by_rowid.sql");
    }

    @Bean("retrieveAltNameByRowId")
    public String retrieveAltNameByRowId() {return readFileSql("queries/retrieve_geographyaltname_by_rowid.sql");  }

    @Bean("retrieveAltCodeByRowId")
    public String retrieveAltCodeByRowId()
    {
        return readFileSql("queries/retrieve_geographyaltcode_by_rowid.sql");
    }

    @Bean("retrieveContinentbyUuid")
    public String retrieveContinentbyUuid()
    {
        return readFileSql("queries/retrieve_geographycontinent_by_uuid.sql");
    }

    @Bean("retrieveCountryByUuid")
    public String retrieveCountryByUuid()
    {
        return readFileSql("queries/retrieve_geographycountry_by_uuid.sql");
    }

    @Bean("retrieveCountryAltCodeByCountryId")
    public String retrieveCountryAltCodeByCountryId()
    {
        return readFileSql("queries/retrieve_geographycountryaltcode_by_rowid.sql");
    }

    @Bean("retrieveParentByUuid")
    public String retrieveParentByUuid()
    {
        return readFileSql("queries/retrieve_geographyparent_by_uuid.sql");
    }

    @Bean("retrieveParentAltCodeByEntityId")
    public String retrieveParentAltCodeByEntityId()
    {
        return readFileSql("queries/retrieve_geographyparentalternatecd_by_rowid.sql");
    }

    @Bean("retrieveGrandParentByUuid")
    public String retrieveGrandParentByUuid()
    {
        return readFileSql("queries/retrieve_geographygrandparent_by_uuid.sql");
    }

    @Bean("retrieveGrandParentAltCodeByEntityId")
    public String retrieveGrandParentAltCodeByEntityId()
    {
        return readFileSql("queries/retrieve_geographygrandparentalternatecd_by_rowid.sql");
    }

    @Bean("retrieveSubCityParentByUuid")
    public String retrieveSubCityParentByUuid()
    {
        return readFileSql("queries/retrieve_geographysubcityparent_by_uuid.sql");
    }

    @Bean("retrieveSubCityParentAltCodeByEntityId")
    public String retrieveSubCityParentAltCodeByEntityId()
    {
        return readFileSql("queries/retrieve_geographysubcityparentalternatecd_by_rowid.sql");
    }

    @Bean("retrieveBdaByUuid")
    public String retrieveBdaByUuid()
    {
        return readFileSql("queries/retrieve_geographybda_by_uuid.sql");
    }

    @Bean("retrieveBdaAltCodeByEntityId")
    public String retrieveBdaAltCodeByEntityId()
    {
        return readFileSql("queries/retrieve_geographybdaaltcd_by_rowid.sql");
    }

    @Bean("retrieveBdaLocationByEntityId")
    public String retrieveBdaLocationByEntityId()
    {
        return readFileSql("queries/retrieve_geographybdalocation_by_rowid.sql");
    }

    @Bean("retrieveBdaLocationAltCodeByEntityId")
    public String retrieveBdaLocationAltCodeByEntityId()
    {
        return readFileSql("queries/retrieve_geographybdalocationaltcode_by_rowid.sql");
    }

    @Bean("empPublishGeoConfiguration")
    public String empPublishGeoConfiguration()
    {

        return "select PROPERTY_NAME, PROPERTY_VALUE from OPS_APPLICATION_CONFIG where APPLICATION_NAME = 'EMP_PUBLISH_GEO-V3'";
    }

    private String readFileSql(String pathToFile) {
        StringBuilder fileContentSB = new StringBuilder();
        try
        {
            InputStream inputStream = new ClassPathResource(pathToFile).getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            fileContentSB.append(br.lines().collect(Collectors.joining(System.lineSeparator())));

            log.debug("fileContentSB ::: "+fileContentSB.toString());
        }
        catch (IOException e)
        {
            log.error("IO Exception while reading file containing query not found in path :: " + pathToFile, e);
        }
        return fileContentSB.toString();
    }
}

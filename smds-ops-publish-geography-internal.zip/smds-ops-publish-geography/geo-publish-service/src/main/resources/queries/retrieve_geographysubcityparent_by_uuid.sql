select
c.rowid as entityId,
c.name,
g.entity_name as type,
null as bdaType
from geo_master_data.city_subarea a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City Sub Area'
inner join geo_master_data.entity_type g on g.rowid = b.parent_type_id
where a.uuid = ?
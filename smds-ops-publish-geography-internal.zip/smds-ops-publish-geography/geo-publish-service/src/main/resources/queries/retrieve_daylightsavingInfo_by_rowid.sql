select
dayLightSavingCode,
dayLightSavingName,
daylightSavingStart,
daylightSavingEnd,
row_number
 from (select
a.code as dayLightSavingCode,
a.name as dayLightSavingName,
b.start_time as daylightSavingStart,
b.end_time as daylightSavingEnd,
b.time_difference as dayLightSavingShiftMinutes,
ROW_NUMBER() OVER (partition by a.code order by b.start_time desc,b.end_time desc)
from geo_master_data.dst a
left outer join geo_master_data.dst_displacement b
on a.rowid = b.dst_rowid
where a.rowid = ?) a where row_number in (1,2)
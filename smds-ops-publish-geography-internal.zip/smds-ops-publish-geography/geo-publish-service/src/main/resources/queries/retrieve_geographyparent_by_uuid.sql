/*Parent Information*/
/*continent country Combination*/
select 
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.country a 
inner join geo_master_data.parent_rel  b on b.child_id = a.uuid 
inner join geo_master_data.continent c on b.parent_id = c.uuid 
inner join geo_master_data.entity_type d on d.rowid = b.child_type_id and d.entity_name='Country'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id 
where  a.uuid = ?
union
/*country state Combination*/
select 
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.state a 
inner join geo_master_data.parent_rel b on b.child_id = a.uuid 
inner join geo_master_data.country c on b.parent_id = c.uuid 
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='State/Prov'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id 
where a.uuid = ?
union
/*state city Combination*/
select 
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.city a 
inner join geo_master_data.parent_rel b on b.child_id = a.uuid 
inner join geo_master_data.state c on b.parent_id = c.uuid 
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id 
where a.uuid = ?
union
/*country  city Combination*/
select 
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy 
from geo_master_data.city a 
inner join geo_master_data.parent_rel b on b.child_id = a.uuid 
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='City'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id
where a.uuid = ?
UNION
/*country  postal code Combination*/
select 
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy 
from geo_master_data.postal_code a 
inner join geo_master_data.parent_rel b on b.child_id = a.uuid 
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='Postal Code'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id
where a.uuid = ?
UNION
/*state  postal code Combination*/
select 
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy 
from geo_master_data.postal_code a 
inner join geo_master_data.parent_rel b on b.child_id = a.uuid 
inner join geo_master_data.state c on b.parent_id = c.uuid 
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id
where a.uuid = ?
UNION
/*city  postal code Combination*/
select 
c.rowid as entityId,
c.name,
e.entity_name as type,
c.longitude as longitude,
c.latitude as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy 
from geo_master_data.postal_code a 
inner join geo_master_data.parent_rel b on b.child_id = a.uuid 
inner join geo_master_data.city c on b.parent_id = c.uuid 
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id
where a.uuid = ?
UNION
/*city  subcity Combination*/
select 
c.rowid as entityId,
c.name,
c.longitude as longitude,
c.latitude as latitude,
case when c.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy 
from geo_master_data.city_subarea a 
inner join geo_master_data.parent_rel b on b.child_id = a.uuid 
inner join geo_master_data.city c on b.parent_id = c.uuid 
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City Sub Area'
inner join geo_master_data.entity_type e on e.rowid = b.parent_type_id
where a.uuid = ?
UNION
/*subcity  postalcode Combination*/
select 
a.rowid as entityId,
a.name,
a.longitude as longitude,
a.latitude as latitude,
case when a.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy 
from geo_master_data.postal_code a0 
inner join geo_master_data.parent_rel a1 on a1.child_id = a0.uuid
inner join geo_master_data.city_subarea a on a1.parent_id = a.uuid
inner join geo_master_data.entity_type h on h.rowid = a1.child_type_id and h.entity_name='Postal Code'
inner join geo_master_data.entity_type e on e.rowid = a1.parent_type_id
where a0.uuid = ?
UNION
/*city    site  Combination*/
select 
a.rowid as entityId,
a.name,
a.longitude as longitude,
a.latitude as latitude,
case when a.status = 'true' then 'Active' 
else 'Inactive' end as status,
e.entity_name as type,
null as bdaType,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy 
from geo_master_data.site a1 
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid 
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Site'
inner join geo_master_data.entity_type e on e.rowid = a2.parent_type_id
where a1.uuid = ?
UNION
/*bda bda  Combination*/
select 
a.rowid as entityId,
a.name,
null as longitude,
null as latitude,
case when a.status = 'true' then 'Active' 
else 'Inactive' end as status,
i.entity_name as type,
e.type as bdaType,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy 
from geo_master_data.bda a1 
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.bda a on a2.parent_id = a.uuid 
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Business Defined Area'
inner join geo_master_data.entity_type i on i.rowid = a2.parent_type_id 
inner join geo_master_data.bda_type e on e.rowid = a.bda_type_id 
where a1.uuid = ?
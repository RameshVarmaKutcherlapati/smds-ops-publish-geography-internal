/*Country Information*/

/*country state Combination*/
select
c.rowid as entityId,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
c.name as name,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.state a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on b.parent_id = c.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='State/Prov'
where a.uuid = ?
union
/*country state city Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.city a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City'
where a.uuid = ?
union
/* country city Combination*/
select
c.rowid as entityId,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
c.name as name,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.city a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='City'
where a.uuid = ?
UNION
/*country  postal code Combination*/
select
c.rowid as entityId,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
c.name as name,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='Postal Code'
where a.uuid = ?
UNION
/*country state  postal code Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
where a.uuid = ?
UNION
/*country city  postal code Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
where  a.uuid = ?
UNION
/*continent country state city  postal code Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.postal_code a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a3 on a2.parent_id = a3.uuid
inner join geo_master_data.parent_rel b on b.child_id = a3.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Postal Code'
where a1.uuid = ?
UNION
/*country  city  subcity Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.city_subarea a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City Sub Area'
where a.uuid = ?
UNION
/*country  state city  subcity Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.city_subarea a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='City Sub Area'
where  a1.uuid = ?
UNION
/*country  city  subcity  postalcode Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.postal_code a0
inner join geo_master_data.parent_rel a1 on a1.child_id = a0.uuid
inner join geo_master_data.city_subarea a on a1.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = a1.child_type_id and h.entity_name='Postal Code'
where a0.uuid = ?
UNION
/*country  state city  subcity  postalcode Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.postal_code a0
inner join geo_master_data.parent_rel a1 on a1.child_id = a0.uuid
inner join geo_master_data.city_subarea a2 on a1.parent_id = a2.uuid
inner join geo_master_data.parent_rel a3 on a3.child_id=a2.uuid
inner join geo_master_data.city a on a3.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = a1.child_type_id and h.entity_name='Postal Code'
where a1.uuid = ?
UNION
/* country   city    site  Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.site a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country e on  b.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Site'
where a1.uuid = ?
UNION
/*country state  city    site  Combination*/
select
e.rowid as entityId,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy,
e.name as name,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.site a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Site'
where a1.uuid = ?
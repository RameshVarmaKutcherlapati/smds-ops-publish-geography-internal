select
b.type_name as codeType,
a.code as code
from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid
where a.entity_id=?
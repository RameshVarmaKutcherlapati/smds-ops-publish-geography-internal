/* BDAS Information */
select 
c.rowid as entityId,
c.name,
'Business Defined Area' as  type,
e.name as bdaType,
c.valid_from as validFrom,
c.valid_to as validTo,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.country a
inner join geo_master_data.bda_rel  b on b.entity_id = a.uuid
inner join geo_master_data.bda c on b.bda_id =  c.rowid
inner join geo_master_data.entity_type d on d.rowid = b.entity_type_id and d.entity_name='Country'
inner join geo_master_data.bda_type e on e.rowid = c.bda_type_id
where  a.uuid = ?
UNION
select
c.rowid as entityId,
c.name,
'Business Defined Area' as  type,
e.name as bdaType,
c.valid_from as validFrom,
c.valid_to as validTo,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.state a
inner join geo_master_data.bda_rel  b on b.entity_id = a.uuid
inner join geo_master_data.bda c on b.bda_id =  c.rowid
inner join geo_master_data.entity_type d on d.rowid = b.entity_type_id and d.entity_name='State/Prov'
inner join geo_master_data.bda_type e on e.rowid = c.bda_type_id
where  a.uuid = ?
UNION
select
c.rowid as entityId,
c.name,
'Business Defined Area' as  type,
e.name as bdaType,
c.valid_from as validFrom,
c.valid_to as validTo,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.city a
inner join geo_master_data.bda_rel  b on b.entity_id = a.uuid
inner join geo_master_data.bda c on b.bda_id =  c.rowid
inner join geo_master_data.entity_type d on d.rowid = b.entity_type_id and d.entity_name='City'
inner join geo_master_data.bda_type e on e.rowid = c.bda_type_id
where  a.uuid = ?
UNION
select
c.rowid as entityId,
c.name,
'Business Defined Area' as  type,
e.name as bdaType,
c.valid_from as validFrom,
c.valid_to as validTo,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.city_subarea a
inner join geo_master_data.bda_rel  b on b.entity_id = a.uuid
inner join geo_master_data.bda c on b.bda_id =  c.rowid
inner join geo_master_data.entity_type d on d.rowid = b.entity_type_id and d.entity_name='City Sub Area'
inner join geo_master_data.bda_type e on e.rowid = c.bda_type_id
where  a.uuid = ?
UNION
select
c.rowid as entityId,
c.name,
'Business Defined Area' as  type,
e.name as bdaType,
c.valid_from as validFrom,
c.valid_to as validTo,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.postal_code a
inner join geo_master_data.bda_rel  b on b.entity_id = a.uuid
inner join geo_master_data.bda c on b.bda_id =  c.rowid
inner join geo_master_data.entity_type d on d.rowid = b.entity_type_id and d.entity_name='Postal Code'
inner join geo_master_data.bda_type e on e.rowid = c.bda_type_id
where  a.uuid = ?
UNION
select
c.rowid as entityId,
c.name,
'Business Defined Area' as  type,
c.valid_from as validFrom,
c.valid_to as validTo,
e.name as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.site a 
inner join geo_master_data.bda_rel  b on b.entity_id = a.uuid
inner join geo_master_data.bda c on b.bda_id =  c.rowid 
inner join geo_master_data.entity_type d on d.rowid = b.entity_type_id and d.entity_name='Site'
inner join geo_master_data.bda_type e on e.rowid = c.bda_type_id
where  a.uuid = ?


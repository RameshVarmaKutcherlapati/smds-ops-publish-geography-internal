/* grand parent  Information*/

/*continent country state Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.state a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.continent e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='State/Prov'
inner join geo_master_data.entity_type g on g.rowid = d.parent_type_id
where a.uuid = ?
union
/*country state city Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.city a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City'
inner join geo_master_data.entity_type g on g.rowid = d.parent_type_id
where a.uuid = ?
union
/*continent country  city Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.city a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.parent_rel d on d.child_id = c.uuid
inner join geo_master_data.continent e on d.parent_id = e.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='City'
inner join geo_master_data.entity_type g on g.rowid = d.parent_type_id
where  a.uuid = ?
UNION
/*continent country  postal code Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.parent_rel d on d.child_id = c.uuid
inner join geo_master_data.continent e on d.parent_id = e.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='Postal Code'
inner join geo_master_data.entity_type g on g.rowid = d.parent_type_id
where a.uuid = ?
UNION
/*country state  postal code Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
inner join geo_master_data.entity_type g on g.rowid = d.parent_type_id
where a.uuid = ?
UNION
/*country city  postal code Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
inner join geo_master_data.entity_type g on g.rowid = d.parent_type_id
where a.uuid = ?
UNION
/*state city  postal code Combination*/
select
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.postal_code a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a3 on a2.parent_id = a3.uuid
inner join geo_master_data.parent_rel b on b.child_id = a3.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Postal Code'
inner join geo_master_data.entity_type g on g.rowid = b.parent_type_id
where a1.uuid = ?
UNION
/*country  city  subcity Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.city_subarea a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City Sub Area'
inner join geo_master_data.entity_type g on g.rowid = d.parent_type_id
where a.uuid = ?
UNION
/*state city  subcity Combination*/
select
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.city_subarea a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='City Sub Area'
inner join geo_master_data.entity_type g on g.rowid = b.parent_type_id
where a1.uuid = ?
UNION
/*city  subcity  postalcode Combination*/
select
c.rowid as entityId,
c.name,
c.longitude as longitude,
c.latitude as latitude,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.postal_code a0
inner join geo_master_data.parent_rel a1 on a1.child_id = a0.uuid
inner join geo_master_data.city_subarea a on a1.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.entity_type h on h.rowid = a1.child_type_id and h.entity_name='Postal Code'
inner join geo_master_data.entity_type g on g.rowid = b.parent_type_id
where a0.uuid = ?
UNION
/*country   city    site  Combination*/
select
e.rowid as entityId,
e.name,
null as longitude,
null as latitude,
case when e.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
e.created_date as createDate,
e.last_modified_date as updateDate,
e.created_by as createdBy,
e.last_modified_by as updatedBy
from geo_master_data.site a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country e on  b.parent_id = e.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Site'
inner join geo_master_data.entity_type g on g.rowid = b.parent_type_id
where a1.uuid = ?
UNION
/*state   city    site  Combination*/
select
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status,
g.entity_name as type,
null as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.site a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Site'
inner join geo_master_data.entity_type g on g.rowid = b.parent_type_id
where a1.uuid = ?
UNION
/*bda   bda    bda  Combination*/
select
c.rowid as entityId,
c.name,
null as longitude,
null as latitude,
case when c.status = 'true' then 'Active'
else 'Inactive' end as status,
i.entity_name as type,
e.type as bdaType,
c.created_date as createDate,
c.last_modified_date as updateDate,
c.created_by as createdBy,
c.last_modified_by as updatedBy
from geo_master_data.bda a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.bda a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel a3 on a3.child_id=a.uuid
inner join geo_master_data.bda c on a3.parent_id = c.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Business Defined Area'
inner join geo_master_data.entity_type i on i.rowid = a3.parent_type_id
inner join geo_master_data.bda_type e on e.rowid = c.bda_type_id
where a1.uuid = ?
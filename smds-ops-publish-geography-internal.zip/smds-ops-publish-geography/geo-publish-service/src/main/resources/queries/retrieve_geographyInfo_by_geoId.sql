select
entityId,
createDate,
updateDate,
createdBy,
updatedBy,
geoId,
geoType,
name,
status,
validFrom,
validTo,
longitude,
latitude,
description,
workaroundReason,
restricted,
postalCodeMandatory,
stateProvinceMandatory,
dialingCode,
dialingCodeDescription,
portFlag,
olsonTimezone,
bdaType,
hsudName,
isMaerskCity,
siteType,
dstId,
timezoneId ,
uuid
FROM(
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
null as longitude,
null as latitude,
a.description,
d.name as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
null as portFlag,
null as olsonTimezone,
null as bdaType,
null as hsudName,
null as isMaerskCity,
null as siteType,
null as dstId,
null as timezoneId,
a.uuid
from geo_master_data.continent a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.workaround_reason d on d.rowid = a.workaround_rowid
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
null as longitude,
null as latitude,
a.description,
d.name as workaroundReason,
a.restricted as restricted,
a.postal_code_mandatory as postalCodeMandatory,
a.state_mandatory as stateProvinceMandatory,
a.dialing_code as dialingCode,
a.dialing_code_description as dialingCodeDescription,
null as portFlag,
null as olsonTimezone,
null as bdaType,
null as hsudName,
null as isMaerskCity,
null as siteType,
a.dst_id as dstId,
a.timezone_id as timezoneId,
a.uuid
from geo_master_data.country a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.workaround_reason d on d.rowid = a.workaround_rowid
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
null as longitude,
null as latitude,
a.description,
d.name as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
null as portFlag,
null as olsonTimezone,
null as bdaType,
null as hsudName,
null as isMaerskCity,
null as siteType,
a.dst_id as dstId,
a.timezone_id as timezoneId,
a.uuid
from geo_master_data.state a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.workaround_reason d on d.rowid = a.workaround_rowid
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
a.longitude as longitude,
a.latitude as latitude,
a.description,
d.name as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
a.port_flag as portFlag,
e.name  as olsonTimezone,
null as bdaType,
null as hsudName,
a.is_maersk_city as isMaerskCity,
null as siteType,
a.dst_id as dstId,
a.timezone_id as timezoneId,
a.uuid
from geo_master_data.city a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.workaround_reason d on d.rowid = a.workaround_rowid
left outer join
geo_master_data.olson_timezone e on a.olson_id = e.rowid
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
a.longitude as longitude,
a.latitude as latitude,
a.description,
null as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
a.port_flag as portFlag,
e.name  as olsonTimezone,
null as bdaType,
a.hsud_name as hsudName,
a.is_maersk_city as isMaerskCity,
null as siteType,
a.dst_id as dstId,
a.timezone_id as timezoneId,
a.uuid
from geo_master_data.city_subarea a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.olson_timezone e on a.olson_id = e.rowid
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
a.longitude as longitude,
a.latitude as latitude,
a.description,
d.name as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
null as portFlag,
null as olsonTimezone,
null as bdaType,
null as hsudName,
null as isMaerskCity,
a.site_type as siteType,
null as dstId,
null as timezoneId,
a.uuid
from geo_master_data.site a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.workaround_reason d on d.rowid = a.workaround_rowid
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
a.longitude as longitude,
a.latitude as latitude,
a.description,
d.name as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
null as portFlag,
null as olsonTimezone,
null as bdaType,
null as hsudName,
null as isMaerskCity,
a.site_type as siteType,
null as dstId,
null as timezoneId,
a.uuid
from geo_master_data.site a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.workaround_reason d on d.rowid = a.workaround_rowid
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
null as longitude,
null as latitude,
a.description,
null as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
null as portFlag,
null as olsonTimezone,
null as bdaType,
null as hsudName,
null as isMaerskCity,
null as siteType,
null as dstId,
null as timezoneId,
a.uuid
from geo_master_data.postal_code a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
UNION
select
a.rowid as entityId,
a.created_date as createDate,
a.last_modified_date as updateDate,
a.created_by as createdBy,
a.last_modified_by as updatedBy,
b.code as geoId,
c.entity_name as geoType,
a.name as name,
case when a.status = 'true' then 'Active'
else 'Inactive' end as status,
a.valid_from as validFrom,
a.valid_to as validTo,
null as longitude,
null as latitude,
null as description,
null as workaroundReason,
null as restricted,
null as postalCodeMandatory,
null as stateProvinceMandatory,
null as dialingCode,
null as dialingCodeDescription,
null as portFlag,
null as olsonTimezone,
d.name as bdaType,
null as hsudName,
null as isMaerskCity,
null as siteType,
null as dstId,
null as timezoneId,
a.uuid
from geo_master_data.bda a  left outer join
(select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.GEOID') b
on a.rowid = cast(b.entity_id as BIGINT)
left outer join
geo_master_data.entity_type c on c.rowid = b.entity_type_id
left outer join
geo_master_data.bda_type d on d.rowid = a.bda_type_id
) a
where geoId=?
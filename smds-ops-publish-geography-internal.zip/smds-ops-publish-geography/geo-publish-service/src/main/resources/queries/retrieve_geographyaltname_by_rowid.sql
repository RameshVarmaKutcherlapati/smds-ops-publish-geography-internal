select
name as name,
description as description,
case when status = 'true' then 'Active'
else 'Inactive' end as status,
created_date as createDate,
last_modified_date as updateDate,
created_by as createdBy,
last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.alt_name where entity_id=?

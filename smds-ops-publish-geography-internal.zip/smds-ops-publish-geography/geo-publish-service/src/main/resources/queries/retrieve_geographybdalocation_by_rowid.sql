select
rowid as entityId,
null as name,
null as type,
case when status = 'true' then 'Active'
else 'Inactive' end as status
from geo_master_data.bda
where entity_id=?
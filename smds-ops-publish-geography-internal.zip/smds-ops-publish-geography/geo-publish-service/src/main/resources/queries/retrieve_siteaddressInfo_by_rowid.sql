select
gps_flag as gpsFlag,
gsm_flag as gsmFlag,
street as street,
postal_code as postalCode,
address_line1 as addressLine1,
address_line2 as addressLine2,
address_line3 as addressLine3,
created_date as createDate,
last_modified_date as updateDate,
created_by as createdBy,
last_modified_by as updatedBy,
null as operation,
null as isChanged
from geo_master_data.site where rowid = ?
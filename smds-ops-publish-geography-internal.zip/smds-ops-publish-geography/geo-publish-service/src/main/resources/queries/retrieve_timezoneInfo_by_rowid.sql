select
code as timezoneCode,
name as timezoneName,
offset_min as utcOffsetMinutes
from geo_master_data.timezone where rowid = ?
/*continent country Combination*/
select e.code,c.name from geo_master_data.country a
inner join geo_master_data.parent_rel  b on b.child_id = a.uuid
inner join geo_master_data.continent c on b.parent_id = c.uuid
inner join geo_master_data.entity_type d on d.rowid = b.child_type_id and d.entity_name='Country'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') e
on c.rowid = cast(e.entity_id as BIGINT) and a.uuid = ?
union
/*continent country state Combination*/
select g.code,e.name from geo_master_data.state a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.continent e on  d.parent_id = e.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='State/Prov'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') g
on e.rowid = cast(g.entity_id as BIGINT) and a.uuid = ?
union
/*continent country state city Combination*/
select i.code,g.name from geo_master_data.city a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a.uuid = ?
union
/*continent country  city Combination*/
select g.code,e.name from geo_master_data.city a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.parent_rel d on d.child_id = c.uuid
inner join geo_master_data.continent e on d.parent_id = e.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='City'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') g
on e.rowid = cast(g.entity_id as BIGINT) and a.uuid = ?
UNION
/*continent country  postal code Combination*/
select g.code,e.name from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country c on  b.parent_id = c.uuid
inner join geo_master_data.parent_rel d on d.child_id = c.uuid
inner join geo_master_data.continent e on d.parent_id = e.uuid
inner join geo_master_data.entity_type f on f.rowid = b.child_type_id and f.entity_name='Postal Code'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') g
on e.rowid = cast(g.entity_id as BIGINT) and a.uuid = ?
UNION
/*continent country state  postal code Combination*/
select i.code,g.name from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a.uuid = ?
UNION
/*continent country city  postal code Combination*/
select i.code,g.name from geo_master_data.postal_code a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='Postal Code'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a.uuid = ?
UNION
/*continent country state city  postal code Combination*/
select i.code,g.name from geo_master_data.postal_code a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a3 on a2.parent_id = a3.uuid
inner join geo_master_data.parent_rel b on b.child_id = a3.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Postal Code'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a1.uuid = ?
UNION
/*continent country  city  subcity Combination*/
select i.code,g.name from geo_master_data.city_subarea a
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = b.child_type_id and h.entity_name='City Sub Area'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a.uuid = ?
UNION
/*continent country  state city  subcity Combination*/
select i.code,g.name from geo_master_data.city_subarea a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='City Sub Area'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a1.uuid = ?
UNION
/*continent country  city  subcity  postalcode Combination*/
select i.code,g.name from geo_master_data.postal_code a0
inner join geo_master_data.parent_rel a1 on a1.child_id = a0.uuid
inner join geo_master_data.city_subarea a on a1.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.city c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = a1.child_type_id and h.entity_name='Postal Code'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a0.uuid = ?
UNION
/*continent country  state city  subcity  postalcode Combination*/
select i.code,g.name from geo_master_data.postal_code a0
inner join geo_master_data.parent_rel a1 on a1.child_id = a0.uuid
inner join geo_master_data.city_subarea a2 on a1.parent_id = a2.uuid
inner join geo_master_data.parent_rel a3 on a3.child_id=a2.uuid
inner join geo_master_data.city a on a3.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = a1.child_type_id and h.entity_name='Postal Code'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a1.uuid = ?
UNION
/*continent country   city    site  Combination*/
select i.code,g.name from geo_master_data.site a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.country e on  b.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Site'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a1.uuid = ?
UNION
/*continent country state  city    site  Combination*/
select i.code,g.name from geo_master_data.site a1
inner join geo_master_data.parent_rel a2 on a2.child_id=a1.uuid
inner join geo_master_data.city a on a2.parent_id = a.uuid
inner join geo_master_data.parent_rel b on b.child_id = a.uuid
inner join geo_master_data.state c on b.parent_id = c.uuid
inner join geo_master_data.parent_rel  d on  d.child_id = c.uuid
inner join geo_master_data.country e on  d.parent_id = e.uuid
inner join geo_master_data.parent_rel f on f.child_id = e.uuid
inner join geo_master_data.continent g on f.parent_id = g.uuid
inner join geo_master_data.entity_type h on h.rowid = a2.child_type_id and h.entity_name='Site'
inner join  (select a.code,a.entity_id,a.entity_type_id from geo_master_data.alt_code a
inner join geo_master_data.code_type b on a.codetype_id = b.rowid and b.type_code='ALT_CODE.CONT_CODE') i
on g.rowid = cast(i.entity_id as BIGINT) and a1.uuid = ?